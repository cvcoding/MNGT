from .train import train
from .val import val
from .test import test

__all__ = ['train', 'val', 'test']
