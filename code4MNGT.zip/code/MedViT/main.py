import torch
from torch import nn
from torchvision import models
import argparse
# from models import *
from MedViT import MedViT
from sklearn.metrics import roc_auc_score
import os
from torch import optim
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset
import matplotlib.pyplot as plt
import torchvision.utils
import numpy as np
import random
from PIL import Image
import PIL.ImageOps
from torch.utils.data.dataset import ConcatDataset
from utilsfile.mask_utils import create_subgraph_mask2coords, create_rectangle_mask, create_rectangle_mask2coords, create_bond_mask2coords
from utilsfile.public_utils import setup_device
from skimage.feature import corner_harris
from skimage.color import rgb2gray
from skimage.restoration import denoise_tv_chambolle
from skimage.feature import corner_peaks
from utilsfile.harris import CornerDetection
import time


# parsers
parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--lr', default=1e-4, type=float, help='learning rate')  # resnets.. 1e-3, Vit..1e-4?
parser.add_argument('--opt', default="adam")
parser.add_argument('--resume', '-r', action='store_true', help='resume from checkpoint')
parser.add_argument('--aug', action='store_true', help='add image augumentations')
parser.add_argument('--mixup', action='store_true', help='add mixup augumentations')
parser.add_argument('--net', default='vit')
parser.add_argument('--bs', default='8')  #64
parser.add_argument('--data_address', default='..\LungImages\\chest_xray_3c\\test', type=str)
parser.add_argument('--n_epochs', type=int, default='0')
parser.add_argument('--n_epochs_tafter', type=int, default='100')
parser.add_argument('--dim', type=int, default='256')
parser.add_argument('--imagesize', type=int, default='784')
parser.add_argument('--patch', default='16', type=int)
parser.add_argument('--num_classes', type=int, default=3)
parser.add_argument('--cos', default='True', action='store_true', help='Train with cosine annealing scheduling')
args = parser.parse_args()

# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
device = 'cuda' if torch.cuda.is_available() else 'cpu'
size = int(args.imagesize)
vit = MedViT(stem_chs=[32, 32, 32], depths=[3, 4, 10, 3], path_dropout=0.1, num_classes=3).to(device)
# vit = ViT(
#         image_size=int(args.imagesize),
#         patch_size=args.patch,
#         kernel_size=5,
#         downsample=0.5,
#         batch_size=args.bs,
#         num_classes=args.num_classes,
#         dim=args.dim,
#         depth=12,
#         heads=8,
#         mlp_dim=args.dim,
#         patch_stride=2,
#         patch_pading=1,
#         in_chans=3,
#         dropout=0.5,  # 0.1
#         emb_dropout=0.5,  # 0.1
#         expansion_factor=2
#     ).to(device)


# Find total parameters and trainable parameters
total_params = sum(p.numel() for p in vit.parameters())
print(f'{total_params:,} total parameters.')
total_trainable_params = sum(
    p.numel() for p in vit.parameters() if p.requires_grad)
print(f'{total_trainable_params:,} training parameters.')

from thop import profile, clever_format
input_shape = (3, 784, 784)
input_tensor = torch.randn(1, *input_shape).to(device)
flops, params = profile(vit, inputs=(input_tensor,))
flops, params = clever_format([flops, params], "%.3f")
print("FLOPs: %s" %(flops))
print("params: %s" %(params))


from warmup_scheduler import GradualWarmupScheduler
opt = torch.optim.Adam(vit.parameters(), lr=args.lr)
scheduler_cosine = torch.optim.lr_scheduler.CosineAnnealingLR(opt, int(args.n_epochs_tafter / 2) + 1)
scheduler = GradualWarmupScheduler(opt, multiplier=2.0, total_epoch=int(args.n_epochs_tafter / 2) + 1,
                                        after_scheduler=scheduler_cosine)

transform_test = transforms.Compose([
    transforms.Resize((size, size)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

##############kaishi

testset = torchvision.datasets.ImageFolder(root='..\LungImages\\chest_xray_3c\\test/', transform=transform_test)
testloader = torch.utils.data.DataLoader(testset, batch_size=32, shuffle=True, num_workers=0)
transf = transforms.ToTensor()
unloader = transforms.ToPILImage()
harris_detector = CornerDetection().to(device)


transform = transforms.Compose([transforms.Resize((size, size)),
                                transforms.RandomCrop(size, padding=2),
                                # transforms.RandomHorizontalFlip(),
                                # transforms.RandomVerticalFlip(),
                                # transforms.RandomGrayscale(p=0.2),
                                # transforms.RandomRotation(degrees=5, fill=(255, 255, 255)),
                                # transforms.GaussianBlur(kernel_size=3, sigma=(2.0, 2.0)),
                                transforms.ToTensor(),
                                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                                ])
train_after_dataset = torchvision.datasets.ImageFolder(root='..\LungImages\\chest_xray_3c\\train', transform=transform)
# for i in range(0):
#     temp = torchvision.datasets.ImageFolder(root='..\LungImages\\chest_xray_2c\\train', transform=transform)
#     train_after_dataset = ConcatDataset([train_after_dataset, temp])

trainafterloader = torch.utils.data.DataLoader(train_after_dataset, batch_size=int(args.bs), shuffle=True, num_workers=0)
if args.cos:
    from warmup_scheduler import GradualWarmupScheduler


# 定义文件datasetm Saving..
# Tue Nov 14 00:27:36 2023 Epoch 35, test loss: 1.56787, acc: 88.67925, roc_auc_avg: 0.89025
# best acc=88
training_dir = args.data_address  # 训练集地址
folder_dataset = torchvision.datasets.ImageFolder(root=training_dir)

criterion_ce = nn.CrossEntropyLoss().to(device)

mean = [0.485, 0.456, 0.406]  # 这些是 ImageNet 的 RGB 通道的均值
std = [0.229, 0.224, 0.225]  # 这些是 ImageNet 的 RGB 通道的标准差

def train_after(epoch):
    print('\nEpoch: %d' % epoch)
    vit.train()
    # learner.online_encoder.required_grad = False
    train_loss = 0
    correct = 0
    total = 0
    accumulation = 16

    for batch_idx, (inputs, targets) in enumerate(trainafterloader):
        inputs, targets = inputs.to(device), targets.to(device)

        # img = inputs.float()
        # images_denorm = img * torch.tensor(std).view(-1, 1, 1).to(device) + torch.tensor(mean).view(-1, 1, 1).to(device)
        # images_denorm = images_denorm.type_as(img)
        # augmented_img1 = unloader(images_denorm[0, :, :, :]).convert('RGB')
        # plt.imshow(augmented_img1, cmap="brg")
        # plt.show()

        outputs = vit(inputs)

        # img1 = torch.empty(inputs.size()).cuda()
        # img2 = torch.empty(inputs.size()).cuda()
        # for i in range(inputs.size(0)):
        #     img1[i, :, :, :], img2[i, :, :, :] = augment_oneimage(inputs[i, :, :])
        # loss0 = learner(img1, img2)

        loss = criterion_ce(outputs, targets)  #+ 0.1*loss0

        loss.backward()
        if ((batch_idx + 1) % accumulation) == 0:
            opt.step()
            opt.zero_grad()

        train_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

    torch.save(vit.state_dict(), './improved-net.pth')

    content = time.ctime() + ' ' + f'Epoch {epoch}, lr: {opt.param_groups[0]["lr"]:.5f}'
    print(content)

    scheduler.step(epoch)

    return train_loss / (batch_idx + 1)


from sklearn.metrics import f1_score, recall_score
def test(epoch):
    global best_acc
    vit.eval()
    test_loss = 0
    correct = 0
    total = 0
    total4roc = 0
    roc_auc = 0

    batch_f1s = []

    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader):
            inputs, targets = inputs.to(device), targets.to(device)
            # empty = torch.Tensor()
            outputs = vit(inputs)
            loss = criterion_ce(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)

            correct += predicted.eq(targets).sum().item()

            # outputssig = outputs  # torch.sigmoid(outputs)
            # _, tempp = outputssig.max(1)
            # try:
            #     roc_auc += roc_auc_score(targets.cpu(), tempp.cpu())
            #     total4roc += 1
            # except ValueError:
            #     pass
            batch_f1 = f1_score(targets.cpu(), predicted.cpu(), average='macro')
            batch_f1s.append(batch_f1)
        average_f1 = np.mean(batch_f1s)
        print(f"Average F1-score: {average_f1:.4f}")



    # Save checkpoint.
    acc = 100. * correct / total
    # if total4roc == 0:
    #     roc_auc_avg = roc_auc / (total4roc+1)
    # else:
    #     roc_auc_avg = roc_auc / total4roc
    if acc > best_acc:
        best_acc = acc

    os.makedirs("log", exist_ok=True)
    content = time.ctime() + ' ' + f'Epoch {epoch}, test loss: {test_loss:.5f}, acc: {(acc):.5f}, average_f1: {(average_f1):.4f}'
    print(content)
    # with open(f'log/log_{args.net}_patch{args.patch}.txt', 'a') as appender:
    #     appender.write(content + "\n")
    return test_loss, acc


# vit.load_state_dict(torch.load('improved-net.pth'), strict=False)

############ train using label $###################################
###################################################################


# optimizer2 = optim.Adam(vit.parameters(), lr=args.lr)
# scheduler_cosine2 = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer2, int(args.n_epochs_tafter / 2) + 1)
# scheduler2 = GradualWarmupScheduler(optimizer2, multiplier=2.0, total_epoch=int(args.n_epochs_tafter / 2) + 1,
#                                         after_scheduler=scheduler_cosine2)

#Thu Jan 18 00:02:24 2024 Epoch 21, test loss: 1.37011, acc: 88.67925, roc_auc_avg: 0.90809

best_acc = 0  # best test accuracy
opt.zero_grad()
for epoch in range(0, args.n_epochs_tafter):
    trainloss = train_after(epoch)

    # learner.update_moving_average()

    test_loss, acc = test(epoch)
    print('best acc=%d' % best_acc)
