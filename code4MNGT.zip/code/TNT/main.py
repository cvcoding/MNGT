import torch
from tnt import TNT
tnt = TNT()
tnt.eval()
inputs = torch.randn(1, 3, 224, 224)
logits = tnt(inputs)
print(logits)
